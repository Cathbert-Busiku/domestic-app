function showDi() {
    document.getElementById("search").style.display = "block";
};